// JavaScript helpers
console.log('Kea’s Mobile Kitchen website loaded');
